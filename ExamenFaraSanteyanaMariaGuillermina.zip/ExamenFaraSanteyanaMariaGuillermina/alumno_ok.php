<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h2>Bienvenido. inicio con éxito</h2>

    <?php
    /**
     * @author Guillermina Fara
     */
    $usuario = $_SESSION["usuario"];
    $email = $_SESSION["email"];
    $cp=$_SESSION["cp"];
    ?>
</body>

</html>