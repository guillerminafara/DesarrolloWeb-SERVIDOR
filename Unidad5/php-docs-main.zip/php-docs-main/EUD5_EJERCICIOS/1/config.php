<?php
//aqui van los datos de la configuracion de la base de datos
$HOST = "192.168.1.117";
$USER = "root";
$PASS = "root";
$DB = "INCIDENCIA";