<?php
//aqui se mostrará la respuesta de la consulta
//supongo que aprendizControllers recibirá
//los datos del formulario y creará la consulta
//la ejecutará y guardará en la sesión
//y luego se cargaran desde la sesión los datos aquí