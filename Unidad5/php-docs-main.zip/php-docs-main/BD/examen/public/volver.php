<?php
//un archivo que limpia la conexion y 
//redirige a index.php
//se llamara desde el submit de un formulario que estara 
//seguramente en la pagina resultado.php