<?php
//aqui van los datos de la configuracion de la base de datos
$HOST = "localhost";
$USER = "root";
$PASS = "";
$DB = "empresa";