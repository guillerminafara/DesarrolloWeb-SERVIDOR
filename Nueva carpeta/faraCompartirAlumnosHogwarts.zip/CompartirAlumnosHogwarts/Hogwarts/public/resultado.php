<?php


// Obtenemosel id del aprendiz o es null

// Si no hay id, mostramos mensaje de error y detenemos la ejecución 
if () {
    die("Acceso no permitido.");
}

// Conectamos a la base de datos 

// Buscamos el aprendiz por su id

// Si no se encuentra el aprendiz, mostramos mensaje de error y detenemos la ejecución
if () {
    die("Aprendiz no encontrado.");
}
?>

<!--Pon un h1 con el texto "Aprendiz registrado correctamente" y tu nombre-->

<?php

    /***
     * Se deben mostrar todos los datos del aprendiz (de la foto mostrar el nommbre y la imagen)
     * Se puede imprimir el HTML directamente aquí (desde PHP) o poner el HTML fuera del bloque PHP.
     * La primera opción demuestra más dominio de PHP, la segunda es más sencilla.
     */
?>

<!-- Agregar botón "Volver al formulario" (NO enlace). Ejecuta el script volver.php-->
<form action="volver.php" method="post">
    
</form>
