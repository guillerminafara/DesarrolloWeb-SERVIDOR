<?php

/*
    TODO: Incluir el archivo Personajes.php 
*/


/**
 * Controlador para manejar las solicitudes HTTP relacionadas con los 
 * personajes de Star Wars.
 */
class PersonajesController
{
    /**
     * Maneja los endpoints de la API RESTful para personajes.
     * Procesa las solicitudes HTTP: GET, POST, PUT, DELETE.
     */
    public function handleRequest()
    {
        /*
            TODO: Establecer cabecera Content-Type: application/json
        */
        $file = "users.json";
        $personajes = json_decode(file_get_contents($file), true);
        /*
            TODO: Obtener el método HTTP desde $_SERVER["REQUEST_METHOD"]
        */
        $metodo = $_SERVER["REQUEST_METHOD"];


        /*
            TODO: Obtener la URI desde $_SERVER["REQUEST_URI"]
            TODO: Dividir la URI en segmentos
            TODO: Extraer el recurso (personajes) y el ID (si existe)
        */
        $uri = $_SERVER["REQUEST_URI"];
        $uri = explode("/", trim($_SERVER["REQUEST_URI"], "/"));
        $resource = isset($uri[0]) ? $uri[0] : null;// para conseguir el usuario, no su nombre
        $id = isset($uri[1]) ? $uri[1] : null; // si existe el dentro de la uri, cargamos variable id


        /*
            TODO: Comprobar que el recurso sea "personajes"
            TODO: Si no lo es, devolver 404 con mensaje JSON
        */
        if ($resource !== "personaje") {
            http_response_code(404);
            echo json_encode(["error" => " character not found"]);
        }

        /*
            ============================================
            RUTA ESPECIAL: GET /personajes/importarSWAPI
            ============================================
            TODO: Detectar esta ruta y llamar a cargarDatosDesdeSWAPI()
        */
        if ($metodo === "GET") {// si es GET
            if (!$id) {// si no hayt id:
                http_response_code(200);// devuelve ok
                echo json_decode($personajes);
                exit;
            }
        }


        /*
            ============================
            RUTAS CRUD
            ============================
        */

        /*
            TODO: GET /personajes
            - Si no hay ID, devolver todos los personajes
            - Llamar a Personajes::getAll()
        */
        if (!$id) {
            echo $personajes::getAll();

        }

        /*
            TODO: GET /personajes/{id}
            - Si hay ID, devolver un personaje concreto
            - Llamar a Personajes::getById($id)
        */
        if ($id) {
            echo $personajes::getById($id);
        }
        /*
            TODO: POST /personajes
            - Leer JSON desde php://input
            - Llamar a Personajes::create($data)
        */

        /*
            TODO: PUT /personajes/{id}
            - Leer JSON desde php://input
            - Llamar a Personajes::update($id, $data)
        */

        /*
            TODO: DELETE /personajes/{id}
            - Llamar a Personajes::delete($id)
            - Devolver código 204
        */
        if ($metodo === "DELETE") {
            $personajes::delete($id);
            http_response_code(204);
        }
        /*
            TODO: Si ninguna ruta coincide, devolver 404
        */ else {
            http_response_code(404);
        }
    }

    /**
     * Carga los datos JSON de la API SWAPI (personajes)
     * y los inserta en la base de datos local.
     */
    public function cargarDatosDesdeSWAPI()
    {
        /*
            TODO: Obtener datos desde la URL https://swapi.dev/api/people/
            TODO: Leer contenido JSON
            TODO: Decodificar JSON
            TODO: Comprobar que existe 'results'
            TODO: Recorrer los personajes recibidos
            TODO: Insertar cada uno usando Personajes::create()
            TODO: Devolver mensaje JSON de éxito o error
        */

        $swapi = "swapi.json";
        $datosDesdeAPI = json_decode(file_get_contents($swapi), true);
        if (!empty($datosDesdeAPI["results"])) {
            foreach ($datosDesdeAPI as $datos) {
                $personaje = new Personajes();
                $personaje::create($datos);

            }
        }

        if ($personaje) {
            echo json_decode([$personaje]);///revisasr
        } else {
            echo json_decode(["error" => "error al agregar el user"]);
            exit;
        }

    }
}