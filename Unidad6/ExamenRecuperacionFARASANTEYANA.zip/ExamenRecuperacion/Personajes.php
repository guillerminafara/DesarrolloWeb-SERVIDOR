<?php

use LDAP\ResultEntry;
/*
    TODO: Incluir el archivo database.php
*/

include_once(__DIR__ . "/Database.php");
/**
 * Clase para manejar operaciones relacionadas con los personajes de Star Wars.
 * Operaciones CRUD: Crear, Leer, Actualizar, Borrar en la tabla 'characters'.
 */

class Personajes
{
    public $nombre;
    /*
        TODO: Implementar método getAll()
        - Debe obtener todos los registros de la tabla 'characters'
        - Usar la conexión PDO
        - Ejecutar SELECT 
        - Devolver los resultados como array asociativo
    */
    public static $pdo;

    public function conectar()
    {
        try {
            //code...
            self::$pdo = new Database();
            self::$pdo = self::$pdo->conectar();

        } catch (mysqli_sql_exception $e) {
            print $e;
        }


    }


    public static function getAll()
    {
        // TODO
        $sql = "select * from characters;";
        $resultado = self::$pdo->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila;
    }

    /*
        TODO: Implementar método getById($id)
        - Debe obtener un personaje por su ID
        - Usar consulta preparada con WHERE id 
        - Ejecutar y devolver un único registro
    */
    public static function getById($id)
    {
        // TODO

        $sql = "select * from characters where id=?;";
        $salida = self::$pdo->prepare($sql);
        $salida->exec(array($id));
        return $salida;
    }

    /*
        TODO: Implementar método create($data)
        - Insertar un nuevo personaje en la tabla
        - Campos: name, gender, height
        - Usar consulta preparada INSERT
        - Ejecutar con los valores recibidos en $data
        - Devolver el personaje recién creado usando getById()
    */
    public static function create($data)
    {
        // TODO

        $sql = "insert into characters(name, gender, height) values(?,?,?);";
        $salida = self::$pdo->prepare($sql);
        $datos = json_decode($data);// me devuelve array comun 
        // $paso = [];

        // $paso[] = $datos["name"];
        // $paso[] = $datos["gender"];
        // $paso[] = $datos["height"];
        $salida->exec($datos);
        $id= $salida.;// ver como conseguir el id del personaje recien creado 
        $personaje = self::getById($id);

    
        return $personaje;
    }

    /*
        TODO: Implementar método update($id, $data)
        - Actualizar un personaje existente
        - Usar UPDATE 
        - Ejecutar con los valores de $data y el id
        - Devolver el personaje actualizado usando getById()
    */
    public static function update($id, $data)
    {
        // TODO
        $sql = "update characters set id=?, data=?";
        // $sql = "update characters set (id=?, data=?)";

        $salida = self::$pdo->prepare($sql);
        $salida->exec(array($id, $data));
        if ($salida === true) {
            echo "<p>" . self::getById() . "</p>";
        } else {
            echo "0 rows affected";
        }
    }

    /*
        TODO: Implementar método delete($id)
        - Borrar un personaje por su ID
        - Usar DELETE 
        - Ejecutar consulta preparada
        - Devolver true/false según éxito
    */
    public static function delete($id)
    {
        // TODO

        $sql = "delete from characters where id=?";
        $salida = self::$pdo->prepare($sql);
        $salida->exec(array($id));
        return $salida ? true : false;
    }
}
