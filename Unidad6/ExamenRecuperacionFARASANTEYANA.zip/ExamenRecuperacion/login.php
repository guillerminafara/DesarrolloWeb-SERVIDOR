<?php
session_start();
/*
    TODO: Iniciar sesión
*/

/*
    TODO: Incluir validaciones.php
*/
include_once(__DIR__ . "/validaciones.php");
/*
    TODO: Leer el archivo users.json y decodificarlo.
    TODO: Extraer solo los nombres autorizados con array_column().
    TODO: Guardar la lista de usuarios autorizados en $_SESSION['listaUsuarios'].
*/
$file = "users.json"; // usamos users!!!
$usuarios = json_decode(file_get_contents($file), true);
//foreach para sumar los nombres a la lista de usuario autorizados
foreach ($usuarios as $user) {
    $nombre = array_column($user, "name");
    $_SESSION["listaUsuarios"] = $nombre;
}

/*
    Array para almacenar errores (lo usarán ellos)
*/
$errores = [];

/*
    TODO: Recoger el nombre enviado por POST (si existe)
*/
$nombre = isset($_POST["nombre"]) ? $_POST["nombre"] : "";

/*
    TODO: Comprobar si la petición es POST
*/
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    /* ============================
       BOTÓN VALIDAR
       ============================ */
    if ($_POST["validar"]) {

        /*
            TODO: Validar el nombre usando:
                - validaRequerido()
                - validaAlfabeto()
            TODO: Si es válido, guardar el nombre en sesión.
            TODO: Si NO es válido, añadir mensajes al array $errores.
        */

        if (!validaAlfabeto($nombre) || validaRequerido($nombre)) {
            $errores = "Campo nombre invalido";
        } else {
            $_SESSION["personaje"] = $nombre;
        }
    }

    /* ============================
       BOTÓN ACCEDER
       ============================ */
    if ($_POST["acceder"]) {
        if (in_array($_SESSION["personajes"], $_SESSION["listaUsuarios"])) {

            header("Location: index.php");
            exit;
        } else {
            die($_SESSION["personajes"]);
            $nombre = "";
            $errores = "Usuario no autorizado";
        }

        /*
            TODO: Recuperar el nombre guardado en sesión.
            TODO: Comprobar si está en la lista de usuarios autorizados.
            TODO: Si está autorizado:
                    - Guardar auth = true
                    - Redirigir a index.php
            TODO: Si NO está autorizado:
                    - Destruir la sesión
                    - Vaciar $nombre
                    - Añadir error "Usuario no autorizado"
        */
    }

    // verificamos que el array se encuentre vacio para poder validar el boton el enviar 
    if (empty($errores)) {
        $validar = true;
    }
}
?>
<!-- 
    TODO: Indica TU NOMBRE en el título
-->
<h1>Acceso a la API de Star Wars - GUILLERMINA FARA</h1>

<!-- 
    TODO: Mostrar errores en lista roja recorriendo el array $errores
-->
<ul style="color:red">
    <?php if (!empty($errores)) {

        foreach ($errores as $e): ?>
            <li>$e</li>
        <?php endforeach;
    } ?>
</ul>
<form action="login.php" method="POST">

    <label>Nombre:</label>

    <!-- 
        TODO: Rellenar el campo con el nombre validado o recuperado de sesión
    -->
    <input type="text" name="nombre" value="<?php $_SESSION["personaje"] ?>">

    <br><br>

    <!-- 
        TODO: Mostrar botón VALIDAR si no se ha validado o hay errores
    -->
    <button type="submit" name="validar">Validar</button>
    <?php if ($validar): ?>
        <button type="submit" name="acceder">Acceder</button>
        <!-- 
        TODO: Mostrar botón ACCEDER si se ha validado correctamente
    -->
    <?php endif ?>
</form>